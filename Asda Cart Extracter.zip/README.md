# foodie-ext
foodie chrome extension
This extension is broken and not considered ready for public use
